#!/bin/sh
# builds oxrev_core (arm64-v8a, static PIE) from src/*.cpp using the NDK standalone clang.
# needs: ANDROID_NDK_HOME (or ANDROID_NDK_ROOT) pointing at an installed NDK.
set -e
: "${ANDROID_NDK_HOME:=$ANDROID_NDK_ROOT}"
[ -n "$ANDROID_NDK_HOME" ] || { echo "set ANDROID_NDK_HOME" >&2; exit 1; }
[ -d "$ANDROID_NDK_HOME" ] || { echo "ANDROID_NDK_HOME=$ANDROID_NDK_HOME does not exist" >&2; exit 1; }

CXX=$(find "$ANDROID_NDK_HOME/toolchains/llvm/prebuilt" -maxdepth 3 -name 'aarch64-linux-android*-clang++' 2>/dev/null | sort -V | tail -1)
if [ -z "$CXX" ]; then
  echo "no aarch64-linux-android*-clang++ under $ANDROID_NDK_HOME/toolchains/llvm/prebuilt" >&2
  find "$ANDROID_NDK_HOME/toolchains/llvm/prebuilt" -maxdepth 2 2>/dev/null >&2 || find "$ANDROID_NDK_HOME" -maxdepth 3 >&2
  exit 1
fi
echo "using: $CXX"

"$CXX" -O2 -std=c++17 -fPIE -pie -static-libstdc++ \
  -Isrc -o oxrev_core \
  src/core_main.cpp src/game.cpp src/il2cpp.cpp src/mem.cpp src/authtok.cpp

echo "ok -> oxrev_core"
